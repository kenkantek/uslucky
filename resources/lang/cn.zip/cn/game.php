<?php

return [
    'title'         => 'Our games',
    'des_powerball' => 'Powerball is a lottery operated by New South Wales Lotteries in New South Wales and the Australian Capital Territory, Tattersalls in Victoria and Tasmania, Golden Casket in Queensland, the South Australia Lotteries Commission, and Lotterywest in Western Australia.',
    'des_mega' => 'Mega Millions (which began as The Big Game in 1996, with the name modified to The Big Game Mega Millions six years later) is an American multi-jurisdictional lottery game; it is offered in 44 states, the District of Columbia, and the U.S. Virgin Islands.',
    'button' => 'Play now'
];