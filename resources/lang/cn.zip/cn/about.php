<?php

return [
    'title'         => 'welcome to :title',
    'sub_title'     => 'Lorem ipsum dolor sit amet consectetuer adipiscin',
    'why_choose_us' => 'why choose us?',
    'testimonials'  => 'testimonials',
];