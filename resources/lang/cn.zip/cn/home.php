<?php

return [
    'button'  => 'Play now',
    'winners' => 'latest winners',
    'social'  => 'Connect with us',
    'show_me' => 'Show me',
    'help_me' => 'Help me',
    'ima' => 'I\'m a',
    'win_number' => 'Winning Numbers',
    'current' => 'see current winning <br>ticket results',
    'next' => 'NEXT DRAW',
    'cash' => 'Cash option',
    'h2' => 'Believe in your win! <span>Good luck!</span>',
    'how' => 'How To Play',
];