<?php

return [
    'title'     => 'Contact form',
    'name'      => 'Your Name',
    'email'     => 'Your email',
    'phone'     => 'Your phone number',
    'message'   => 'Message',
    'reset'     => 'Reset',
    'submit'    => 'Submit',
    'mobile'    => 'Freephone',
    'telephone' => 'Telephone',

];