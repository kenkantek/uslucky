<?php

return [
    'title'   => 'CHECK LOTTERY RESULTS ONLINE',
    'from'    => 'Draw Date From',
    'to'      => 'Draw Date To',
    'game'    => 'Game Type',
    'search'  => 'Search',
    'name'    => 'Game name',
    'result'  => 'Results',
    'date'    => 'Date',
    'play'    => 'PowerPlay',
    'jackpot' => 'Estimated Jackpot',
    'wait'    => 'waiting',
    'des'     => '<p>Check the latest winning numbers for the draws below featuring jackpots worth <a href="#" class="link2">$ 647,559,209</a>!  Follow your favourites with FREE lottery result alerts by setting your preferences here or download one of theLotter\'s FREE results apps for iPhone, Android, or iPad to keep the most important lottery results with you on the go!</p><br>
          	<p>Find results, see winning numbers, or select from the list below to check results for all lotteries at the Lottery.</p>'
];